
//1//

let a = 4;
let b = 5;

if (a > b) {
    console.log(a)
}
else {
    console.log(b)
}

//2//

let x = 2;
let y = 5;
let z = -3;

if (x > 0) {
    console.log('the sign is: plus')
}

if (y > 0) {
    console.log('the sign is: plus')
}

if (z < 0) {
    console.log('the sign is: minus')
}

//3//




//4//

a = 1
b = 2
c = 3
d = 4
e = 5




//5//

for (let i = 0; i <= 15; i++) {
    if (i % 2) {
        console.log(i + ' is odd')
    }
    else {
        console.log(i + ' is even')
    }

}

//6//

let da = 80;
let vi = 77;
let di = 88;
let is = 95;
let th = 68;

console.log((da + vi + di + is + th) % 5)

if (da <= 80) {
    console.log('C')
}
if (vi < 80) {
    console.log('C')
}
if (di < 90) {
    console.log('B')
}
if (is < 100) {
    console.log('A')
}
if (th < 70) {
    console.log('D')
}

//7//

for (let i = 1; i <= 100; i++) {
    if (i % 5 && i % 3) {
        console.log(i + ' fizzbuzz')
    }
    else if (i % 3) {
        console.log(i + ' fizz')
    }
    else if (i % 5) {
        console.log(i + ' buzz')
    }

    else {
        console.log(i)
    }
}

//8//

//10//

for (x = 1; x < 6; x++) {
    console.log('*')
}

